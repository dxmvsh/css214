//
//  Club.swift
//  SDU
//
//  Created by Dimash on 10/15/19.
//  Copyright © 2019 Dimash. All rights reserved.
//

import Foundation
import UIKit

struct Club {
    var name: String
    var description: String
    var image: UIImage
}

//
//  Faculty.swift
//  SDU
//
//  Created by Dimash on 10/15/19.
//  Copyright © 2019 Dimash. All rights reserved.
//

import Foundation

struct Faculty {
    var name: String
    var description: String
    var programs: [Program]
}

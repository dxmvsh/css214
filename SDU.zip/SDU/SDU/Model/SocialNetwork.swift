//
//  SocialNetwork.swift
//  SDU
//
//  Created by Dimash on 10/15/19.
//  Copyright © 2019 Dimash. All rights reserved.
//

import Foundation

struct SocialNetwork {
    var name: String
    var url: URL
}

//
//  Contact.swift
//  SDU
//
//  Created by Dimash on 10/15/19.
//  Copyright © 2019 Dimash. All rights reserved.
//

import Foundation

struct Contact {
    var phoneNumber: String
    var email: String
}
